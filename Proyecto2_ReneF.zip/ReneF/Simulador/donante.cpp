#include <string>
#include <sstream>
#include "persona.h"
#include "donante.h"

using namespace std;
using std::stringstream;

Donante::Donante(string nom, string apel, double vida, string origen)
        :Persona(nom, apel, vida), origen(origen){
}

Donante::Donante(const Donante& donante)
        :Donante(donante), origen(donante.origen){
}

void Donante::setOrigen(string origen){
    this->origen = origen;
}

double Donante::getEfecto()const{
    return 14.7;
}

