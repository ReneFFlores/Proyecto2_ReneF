#pragma once

#include <string>
#include "persona.h"
#include <sstream>

using namespace std;
using std::string;
using std::stringstream;

class Donante:public Persona{
    string origen;
public:
    Donante(string, string, double, string);
    Donante(const Donante&);
    void setOrigen(string);
    virtual double getEfecto()const;
};

