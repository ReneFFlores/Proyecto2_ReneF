#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QTextEdit>
#include <QString>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "persona.h"
#include "donante.h"
#include "maleante.h"

using std::stringstream;
using std::string;
using std::ifstream;
using std::ofstream;
using std::vector;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow){
    ui->setupUi(this);
}

MainWindow::~MainWindow(){
    delete ui;
}

void MainWindow::on_pushButton_4_clicked(){
    //Guardar en el archivo
    //Salir
    ofstream new_life("life.txt");
    new_life << 10.00;
    new_life << " ";
    new_life << 100;
    new_life.close();
    exit(0);
}

void MainWindow::on_iniciar_simulador_clicked(){
    //Iniciar simulador
    srand(time(0));
    ifstream fin("lugares.txt");

    //variables
    string city, country;
    int total_lugares, lugar_random;

    vector<string> lugar;


    fin >> total_lugares;

    for(int i = 0; i < total_lugares; i++){
        string temp = "";
        fin >> city;
        fin >> country;
        replace(city.begin(), city.end(), '_', ' ');
        replace(country.begin(), country.end(), '_', ' ');
        temp+=city;
        temp+=", ";
        temp+=country;
        lugar.push_back(temp);
    }

    QString cad0 = QString::fromStdString("Usted ha llegado a:");
    ui->bitacora->append(cad0);
    lugar_random = rand() % total_lugares;
    QString cad = QString::fromStdString(lugar[lugar_random]);
    ui->bitacora->append(cad);
    QString cad2 = QString::fromStdString("---------------------------------------------------------");
    ui->bitacora->append(cad2);


}

void MainWindow::on_sleep_clicked(){
    //Actividad de descansar (gana vida, pierde puntos)

    //declara un random
    srand(time(0));

    //importa/lee archivo life
    ifstream life("life.txt");

    //variables de la funcion
    double vida;
    int experience, deduccion;

    //lecturas
    life >> vida;
    life >> experience;

    //random de deducciones
    srand(time(0));
    deduccion = rand() % 7 + 1;

    //cambios, concatenaiones...
    stringstream ss1, ss2, ss3, ss4;
    vida+=1.5;
    experience-=deduccion;
    ss2 << "Usted ha descansado, ahora " << vida << " de vida.";
    ss3 << "Se le ha reducido a " << experience << " puntos de experiencia";
    ss4 << "---------------------------------------------------------";
    string frase1 = ss1.str();
    string frase2 = ss2.str();
    string frase3 = ss3.str();
    string frase4 = ss4.str();

    //TextAppnend
    QString cad1 = QString::fromStdString(frase1);
    ui->bitacora->append(cad1);
    QString cad2 = QString::fromStdString(frase2);
    ui->bitacora->append(cad2);
    QString cad3 = QString::fromStdString(frase3);
    ui->bitacora->append(cad3);
    QString cad4 = QString::fromStdString(frase4);
    ui->bitacora->append(cad4);

    //Imprime puntuacion en archivo
    ofstream new_life("life.txt");
    new_life << vida;
    new_life << " ";
    new_life << experience;
    new_life.close();
}

void MainWindow::on_pushButton_clicked(){
    //Iniciar simulador
    srand(time(0));
    ifstream fin("lugares.txt");

    //variables
    string city, country;
    int total_lugares;

    fin >> total_lugares;

    for(int i = 0; i < total_lugares; i++){
        string temp = "";
        fin >> city;
        fin >> country;
        replace(city.begin(), city.end(), '_', ' ');
        replace(country.begin(), country.end(), '_', ' ');
        temp+=city;
        temp+=", ";
        temp+=country;

        QString cad1 = QString::fromStdString(temp);
        ui->bitacora->append(cad1);
    }
}

void MainWindow::on_pushButton_3_clicked(){
    srand(time(0));
    ifstream fin("lugares.txt");

    //variables
    string city, country;
    int total_lugares;

    fin >> total_lugares;

    for(int i = 0; i < total_lugares; i++){
        string temp = "";
        fin >> city;
        fin >> country;
        replace(city.begin(), city.end(), '_', ' ');
        replace(country.begin(), country.end(), '_', ' ');
        temp+=city;
        temp+=", ";
        temp+=country;

        QString cad1 = QString::fromStdString(temp);
        ui->bitacora->append(cad1);
    }
}
