#include <string>
#include <sstream>
#include "persona.h"
#include "maleante.h"

using namespace std;
using std::stringstream;

Maleante::Maleante(string nom, string apel, double vida, int puntos):Persona(nom, apel, vida){
}

void Maleante::setPuntos(int puntos){
    this->puntos = puntos;
}

virtual double Maleante::getEfecto()const{
    return -14.5;
}
