#pragma once

#include <string>
#include "persona.h"
#include <sstream>

using namespace std;
using std::string;
using std::stringstream;

class Maleante:public Persona{
    int puntos;
public:
    Maleante(string, string, double, int);
    void setPuntos(int);
    virtual double getEfecto()const;
};
