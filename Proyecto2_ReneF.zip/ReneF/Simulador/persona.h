#pragma once
#include <string>

using std::string;

class Persona{
protected:
    string nom;
    string apel;
    double vida;
public:
    Persona(string,string,double);
    Persona(const Persona&);
    virtual double getEfecto()const = 0;
    string getNom()const;
    void setNom(string);
    string getApel()const;
    void setApel(string);
    double getVida()const;
    void setVida(double);
};
