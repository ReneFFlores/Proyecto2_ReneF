#include <string>
#include <sstream>
#include "persona.h"
#include "donante.h"

using namespace std;
using std::stringstream;

Donante::Donante(string nom, string apel, string objeto, double vida, string origen)
        :Persona(nom, apel, objeto, vida){
    this->origen = origen;
}

void Donante::setOrigen(string){
    this->origen = origen;
}

string Donante::getOrigin(){
    return origen;
}

/*string Donante::getEvento()const{
    stringstream ss;
    ss << " " << Persona::getApel() << " de origen " << origen << " le dara " << Persona::getObj();
    return ss.str();
}*/

double Donante::getEfecto(){
    return getVida();
}
