#pragma once

#include <string>
#include "persona.h"
#include <sstream>

using namespace std;
using std::string;
using std::stringstream;

class Donante:public Persona{
    string origen;
public:
    Donante(string, string, string, double, string);
    void setOrigen(string);
    string getOrigin();
    //string getEvento()const;
    double getEfecto();
};
