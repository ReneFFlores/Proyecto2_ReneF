#include <string>
#include <sstream>
#include "persona.h"
#include "maleante.h"

using namespace std;
using std::stringstream;

Maleante::Maleante(string nom, string apel, string objeto, double vida, int puntos)
        :Persona(nom, apel, objeto, vida){
    this->puntos = puntos;
}

void Maleante::setPuntos(int puntos){
    this->puntos = puntos;
}

string Maleante::getPuntos(){
    return puntos;
}

string Maleante::getEvento()const{
    stringstream ss;
    ss << " que lo asalta con " << Persona::getObj() << " le quitó " << Persona::getVida() << " puntos de salud";
    return ss;
}

virtual double Maleante::getEfecto()const{
    return -getVida();
}
