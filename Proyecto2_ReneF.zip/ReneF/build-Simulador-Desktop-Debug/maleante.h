#pragma once

#include <string>
#include "persona.h"
#include <sstream>

using namespace std;
using std::string;
using std::stringstream;

class Maleante:public Persona{
    int puntos;
public:
    Maleante(string, string, string, double, int);
    void setPuntos(int);
    int getPuntos();
    virtual string getEvento()const;
    virtual double getEfecto()const;
};
