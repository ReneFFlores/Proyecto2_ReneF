#include "persona.h"
#include <string>
#include <sstream>

using std::string;
using std::stringstream;

Persona::Persona(string nom, string apel, string objeto, double vida){
    this->nom = nom;
    this->apel = apel;
    this->objeto = objeto;
    this->vida = vida;
}

Persona::Persona(const Persona& other){
        :nom(other.nom), apel(other.apel), objeto(other.objeto), vida(other.vida);
}

//string Persona::getEvento()const{}

double Persona::getEfecto(const Persona& other){
    return 15.5;
}

string Persona::getNom()const{
    return nom;
}

void Persona::setNom(string nom){
    this->nom = nom;
}

string Persona::getApel()const{
    return apel;
}

void Persona::setApel(string apel){
    this->apel = apel;
}

string Persona::getObj()const{
    return objeto;
}

void Persona::setObj(string objeto){
    this->objeto = objeto;
}

double Persona::getVida()const{
    return vida;
}

void Persona::setVida(double vida){
    this->vida = vida;
}
