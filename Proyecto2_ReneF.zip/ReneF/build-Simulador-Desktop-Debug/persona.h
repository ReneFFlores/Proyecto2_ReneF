#pragma once
#include <string>

using std::string;

class Persona{
protected:
    string nom;
    string apel;
    string objeto;
    double vida;
public:
    Persona(string,string,string, double);
    Persona(const Persona&);
    //virtual string getEvento()const;
    virtual double getEfecto(const Persona&);
    string getNom()const;
    void setNom(string);
    string getApel()const;
    void setApel(string);
    string getObj()const;
    void setObj(string);
    double getVida()const;
    void setVida(double);
};
