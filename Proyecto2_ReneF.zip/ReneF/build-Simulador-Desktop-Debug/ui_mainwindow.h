/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *sleep;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QTextEdit *bitacora;
    QLabel *label;
    QPushButton *iniciar_simulador;
    QPushButton *pushButton;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(861, 350);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        sleep = new QPushButton(centralWidget);
        sleep->setObjectName(QStringLiteral("sleep"));
        sleep->setGeometry(QRect(20, 90, 101, 27));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 130, 101, 27));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 170, 101, 27));
        bitacora = new QTextEdit(centralWidget);
        bitacora->setObjectName(QStringLiteral("bitacora"));
        bitacora->setGeometry(QRect(330, 50, 511, 251));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(340, 20, 111, 17));
        iniciar_simulador = new QPushButton(centralWidget);
        iniciar_simulador->setObjectName(QStringLiteral("iniciar_simulador"));
        iniciar_simulador->setGeometry(QRect(20, 50, 101, 27));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(170, 50, 111, 31));
        pushButton->setIconSize(QSize(110, 150));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        sleep->setText(QApplication::translate("MainWindow", "Descansar", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "Listar Lugares", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "Salir", 0));
        label->setText(QApplication::translate("MainWindow", "Bit\303\241cora de viaje", 0));
        iniciar_simulador->setText(QApplication::translate("MainWindow", "Viajar", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Ir->", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
